/**
 * Clase que representa a un peon en el juego de ajedrez.
 * @author Erik Egido Blanes
 * @version 1.2 
 * @since 2023-05-05
 */

package pieces;

import java.util.ArrayList;

import chess.Cell;

public class Pawn extends Piece {

	/**
	 * 
	 * Constructor de la clase Pawn.
	 * 
	 * @param i Identificador de la pieza.
	 * @param p Ruta de la imagen asociada a la pieza.
	 * @param c Color de la pieza (0 para blanco, 1 para negro).
	 */
	public Pawn(String i, String p, int c) {
		setId(i);
		setPath(p);
		setColor(c);
	}

	/**
	 * 
	 * Método que calcula los posibles movimientos de una pieza Peón.
	 * 
	 * @param state Matriz que representa el estado actual del tablero.
	 * 
	 * @param x     Coordenada x de la posición de la pieza.
	 * 
	 * @param y     Coordenada y de la posición de la pieza.
	 * 
	 * @return ArrayList de objetos Cell que representan las celdas a las que el
	 *         Peón puede moverse.
	 */
	public ArrayList<Cell> move(Cell state[][], int x, int y) {
		// Lista de posibles movimientos
		possiblemoves.clear();

		// Movimientos para Peones blancos
		if (getcolor() == 0) {
			// Movimiento hacia adelante
			if (x > 0 && state[x - 1][y].getpiece() == null) {
				possiblemoves.add(state[x - 1][y]);
				// Primer movimiento, puede avanzar dos casillas
				if (x == 6 && state[4][y].getpiece() == null)
					possiblemoves.add(state[4][y]);
			}
		}
	}
}