/**
 * Classe de la figura que representa al Rey.
 * @author Erik Egido Blanes
 * @version 1.2
 * @since 2023-05-05
 */


/**
*	Clase King que representa una pieza del juego de ajedrez.
* 	Extiende la clase Piece y sobrescribe el método move() y isindanger()
* 	@see Piece
*/


package pieces;
import java.util.ArrayList;

import chess.Cell;

public class King extends Piece{ private int x,y; 

	/**
	 * Constructor de la clase King
	 * @param i String que representa el id de la pieza
	 * @param p String que representa la ruta de la imagen asociada a la pieza
	 * @param c int que representa el color de la pieza (0 para blancas, 1 para negras)
	 * @param x int que representa la posición en x de la pieza en el tablero
	 * @param y int que representa la posición en y de la pieza en el tablero
	 */
	public King(String i,String p,int c,int x,int y)
	{
		setx(x);
		sety(y);
		setId(i);
		setPath(p);
		setColor(c);
	}
	
	/**
	 * Método setx que establece la posición en x de la pieza
	 * @param x int que representa la posición en x de la pieza en el tablero
	 */
	public void setx(int x)
	{
		this.x=x;
	}
	
	/**
	 * Método sety que establece la posición en y de la pieza
	 * @param y int que representa la posición en y de la pieza en el tablero
	 */
	public void sety(int y)
	{
		this.y=y;
	}
	
	/**
	 * Método getx que devuelve la posición en x de la pieza
	 * @return int que representa la posición en x de la pieza en el tablero
	 */
	public int getx()
	{
		return x;
	}
	
	/**
	 * Método gety que devuelve la posición en y de la pieza
	 * @return int que representa la posición en y de la pieza en el tablero
	 */
	public int gety()
	{
		return y;
	}
	
	/**
	 * Método move que sobrescribe el de la clase Piece.
	 * Devuelve un ArrayList con las celdas a las que la pieza puede moverse.
	 * @param state Cell[][] que representa el estado actual del tablero
	 * @param x int que representa la posición en x de la pieza en el tablero
	 * @param y int que representa la posición en y de la pieza en el tablero
	 * @return ArrayList<Cell> con las celdas a las que la pieza puede moverse
	 */
	public ArrayList<Cell> move(Cell state[][],int x,int y)
	{
		possiblemoves.clear();
		int posx[]={x,x,x+1,x+1,x+1,x-1,x-1,x-1};
		int posy[]={y-1,y+1,y-1,y,y+1,y-1,y,y+1};
		for(int i=0;i<8;i++)
			if((posx[i]>=0&&posx[i]<8&&posy[i]>=0&&posy[i]<8))
				if((state[posx[i]][posy[i]].getpiece()==null||state[posx[i]][posy[i]].getpiece().getcolor()!=this.getcolor()))
					possiblemoves.add(state[posx[i]][posy[i]]);
		return possiblemoves;
	}
	
}