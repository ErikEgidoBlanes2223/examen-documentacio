/**
 * Clase que representa a una Torre en el juego de ajedrez.
 * @author Erik Egido Blanes
 * @version 1.2
 * @since 2023-05-05
 */

package pieces;

import java.util.ArrayList;

import chess.Cell;


public class Rook extends Piece{
	
	// Este es un constructor para la clase Rook que toma tres parámetros: una Cadena para el id de la
	// Torre, una cadena para la ruta del archivo de imagen que representa la torre y un número entero para el color
	// de la Torre. El constructor establece estos valores utilizando los métodos setId(), setPath() y setColor()
	// de la clase Pieza.
	public Rook(String i,String p,int c)
	{
		setId(i);
		setPath(p);
		setColor(c);
	}
	
	// El comentario `//Mover función definida` simplemente indica el inicio de la función `mover()`
	// definición de la clase `Torre`. Esta función se encarga de determinar todas las posibles
	// movimientos que puede hacer una torre dado el estado actual del tablero de ajedrez. La función toma en 2D
	// matriz de objetos `Celda` que representan el estado actual de la placa, así como el actual
	// posición de la torre en el tablero (especificada por sus coordenadas x e y). La función entonces
	// calcula todos los movimientos posibles que puede hacer la torre iterando sobre las celdas en el mismo
	// fila y columna como la torre, y agregar celdas vacías o celdas que contengan una pieza del oponente a una
	// lista de posibles movimientos. Finalmente, la función devuelve esta lista de posibles movimientos.
	// Función de movimiento definida
	public ArrayList<Cell> move(Cell state[][],int x,int y)	{
		
		possiblemoves.clear();
		int tempx=x-1;
		while(tempx>=0)
		{
			if(state[tempx][y].getpiece()==null)
				possiblemoves.add(state[tempx][y]);
			else if(state[tempx][y].getpiece().getcolor()==this.getcolor())
				break;
			else
			{
				possiblemoves.add(state[tempx][y]);
				break;
			}
			tempx--;
		}
		tempx=x+1;
		while(tempx<8)
		{
			if(state[tempx][y].getpiece()==null)
				possiblemoves.add(state[tempx][y]);
			else if(state[tempx][y].getpiece().getcolor()==this.getcolor())
				break;
			else
			{
				possiblemoves.add(state[tempx][y]);
				break;
			}
			tempx++;
		}
		int tempy=y-1;
		while(tempy>=0)
		{
			if(state[x][tempy].getpiece()==null)
				possiblemoves.add(state[x][tempy]);
			else if(state[x][tempy].getpiece().getcolor()==this.getcolor())
				break;
			else
			{
				possiblemoves.add(state[x][tempy]);
				break;
			}
			tempy--;
		}
		tempy=y+1;
		while(tempy<8)
		{
			if(state[x][tempy].getpiece()==null)
				possiblemoves.add(state[x][tempy]);
			else if(state[x][tempy].getpiece().getcolor()==this.getcolor())
				break;
			else
			{
				possiblemoves.add(state[x][tempy]);
				break;
			}
			tempy++;
		}
		return possiblemoves;
	}
}
