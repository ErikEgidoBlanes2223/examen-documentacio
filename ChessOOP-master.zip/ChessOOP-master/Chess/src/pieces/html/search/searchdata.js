var indexSectionsWithContent =
{
  0: "bcgkmpqrs",
  1: "bckpqr",
  2: "p",
  3: "bcgkmps",
  4: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables"
};

