var searchData=
[
  ['pawn_0',['Pawn',['../classpieces_1_1_pawn.html#ab0f92a6f170756df336233a9e5da8849',1,'pieces::Pawn']]]
];
