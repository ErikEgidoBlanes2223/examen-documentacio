var searchData=
[
  ['caballo_0',['Caballo',['../classpieces_1_1_caballo.html',1,'pieces']]]
];
