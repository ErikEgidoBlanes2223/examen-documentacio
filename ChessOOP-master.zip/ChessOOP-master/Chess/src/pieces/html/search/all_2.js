var searchData=
[
  ['getcolor_0',['getColor',['../classpieces_1_1_pieza.html#a07fdbf1190615e33572382bc4fc04b56',1,'pieces::Pieza']]],
  ['getcopia_1',['getCopia',['../classpieces_1_1_pieza.html#a5394e895270f36acd4bbc6ba7d0075f8',1,'pieces::Pieza']]],
  ['getid_2',['getId',['../classpieces_1_1_pieza.html#a507c1f8508febc6717c4a6cee60cab8a',1,'pieces::Pieza']]],
  ['getpath_3',['getPath',['../classpieces_1_1_pieza.html#a535465c46241775fa1e49ade0d55d8b4',1,'pieces::Pieza']]],
  ['getx_4',['getx',['../classpieces_1_1_king.html#af18ad8ae71d8f3b78f54ed079ebf0009',1,'pieces::King']]],
  ['gety_5',['gety',['../classpieces_1_1_king.html#a56357600c81542772091388891fe772b',1,'pieces::King']]]
];
