var searchData=
[
  ['bishop_0',['Bishop',['../classpieces_1_1_bishop.html',1,'pieces']]]
];
