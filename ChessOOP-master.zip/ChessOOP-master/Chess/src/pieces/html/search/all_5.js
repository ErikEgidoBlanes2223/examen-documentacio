var searchData=
[
  ['pawn_0',['Pawn',['../classpieces_1_1_pawn.html#ab0f92a6f170756df336233a9e5da8849',1,'pieces.Pawn.Pawn()'],['../classpieces_1_1_pawn.html',1,'pieces.Pawn']]],
  ['pieces_1',['pieces',['../namespacepieces.html',1,'']]],
  ['pieza_2',['Pieza',['../classpieces_1_1_pieza.html',1,'pieces']]],
  ['possiblemoves_3',['possiblemoves',['../classpieces_1_1_pieza.html#ad8be5506cbaa4d65d1d348dbb5b8451c',1,'pieces::Pieza']]]
];
