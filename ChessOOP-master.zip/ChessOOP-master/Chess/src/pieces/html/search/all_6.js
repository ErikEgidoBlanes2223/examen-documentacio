var searchData=
[
  ['queen_0',['Queen',['../classpieces_1_1_queen.html',1,'pieces']]]
];
