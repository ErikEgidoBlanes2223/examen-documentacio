var searchData=
[
  ['caballo_0',['Caballo',['../classpieces_1_1_caballo.html#a44169ab33e0c232bdf8ca7d04c167d62',1,'pieces.Caballo.Caballo()'],['../classpieces_1_1_caballo.html',1,'pieces.Caballo']]]
];
