var searchData=
[
  ['possiblemoves_0',['possiblemoves',['../classpieces_1_1_pieza.html#ad8be5506cbaa4d65d1d348dbb5b8451c',1,'pieces::Pieza']]]
];
