var searchData=
[
  ['pawn_0',['Pawn',['../classpieces_1_1_pawn.html',1,'pieces']]],
  ['pieza_1',['Pieza',['../classpieces_1_1_pieza.html',1,'pieces']]]
];
