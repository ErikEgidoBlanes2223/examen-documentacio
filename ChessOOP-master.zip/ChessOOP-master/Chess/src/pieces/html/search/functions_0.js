var searchData=
[
  ['bishop_0',['Bishop',['../classpieces_1_1_bishop.html#ab05e1a97eca03699aa291bfa43c6efce',1,'pieces::Bishop']]]
];
