var searchData=
[
  ['king_0',['King',['../classpieces_1_1_king.html#a9634b953030b6a6bb696465a24136481',1,'pieces::King']]]
];
