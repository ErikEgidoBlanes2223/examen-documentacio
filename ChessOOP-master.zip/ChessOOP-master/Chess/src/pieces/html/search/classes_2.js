var searchData=
[
  ['king_0',['King',['../classpieces_1_1_king.html',1,'pieces']]]
];
