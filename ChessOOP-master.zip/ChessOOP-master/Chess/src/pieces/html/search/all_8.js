var searchData=
[
  ['setcolor_0',['setColor',['../classpieces_1_1_pieza.html#a60ad9663b61e81c01f35337b87d5bcf7',1,'pieces::Pieza']]],
  ['setid_1',['setId',['../classpieces_1_1_pieza.html#a65dd4d328f6b878efa30a800452c0adb',1,'pieces::Pieza']]],
  ['setpath_2',['setPath',['../classpieces_1_1_pieza.html#a358b1cd29dfe86288b4c7b70385d9d5f',1,'pieces::Pieza']]],
  ['setx_3',['setx',['../classpieces_1_1_king.html#a50abc32a712bcea91dd14ab56271fb3e',1,'pieces::King']]],
  ['sety_4',['sety',['../classpieces_1_1_king.html#ad2cc9233c35a950bedc47bf7626d0b4d',1,'pieces::King']]]
];
