/**
 * @author Erik Egido Blanes
 * @version 1.2
* @since 2023-05-05
 */

package pieces;

import java.util.ArrayList;
import chess.Cell;

public class Bishop extends Piece {

	/**
	 * Constructor de la clase Bishop
	 * 
	 * @param i identificador de la pieza
	 * @param p ruta de la imagen de la pieza
	 * @param c color de la pieza (0 para blanco, 1 para negro)
	 */
	public Bishop(String i, String p, int c) {
		setId(i);
		setPath(p);
		setColor(c);
	}

	/**
	 * Función que retorna un arreglo con las celdas a las que puede mover la pieza
	 * 
	 * @param state arreglo de celdas que representa el estado actual del tablero
	 * @param x     posición en x de la pieza
	 * @param y     posición en y de la pieza
	 * @return ArrayList con las celdas a las que puede mover la pieza
	 */
	public ArrayList<Cell> move(Cell state[][], int x, int y) {
		possiblemoves.clear();
		int tempx = x + 1, tempy = y - 1;
		while (tempx < 8 && tempy >= 0) {
			if (state[tempx][tempy].getpiece() == null) {
				possiblemoves.add(state[tempx][tempy]);
			} else if (state[tempx][tempy].getpiece().getcolor() == this.getcolor()) {
				break;
			} else {
				possiblemoves.add(state[tempx][tempy]);
				break;
			}
			tempx++;
			tempy--;
		}
		tempx = x - 1;
		tempy = y + 1;
		while (tempx >= 0 && tempy < 8) {
			if (state[tempx][tempy].getpiece() == null) {
				possiblemoves.add(state[tempx][tempy]);
			} else if (state[tempx][tempy].getpiece().getcolor() == this.getcolor()) {
				break;
			} else {
				possiblemoves.add(state[tempx][tempy]);
				break;
			}
			tempx--;
			tempy++;
		}
		tempx = x - 1;
		tempy = y - 1;
		while (tempx >= 0 && tempy >= 0) {
			if (state[tempx][tempy].getpiece() == null) {
				possiblemoves.add(state[tempx][tempy]);
			} else if (state[tempx][tempy].getpiece().getcolor() == this.getcolor()) {
				break;
			} else {
				possiblemoves.add(state[tempx][tempy]);
				break;
			}
			tempx--;
			tempy--;
		}
		tempx = x + 1;
		tempy = y + 1;
		while (tempx < 8 && tempy < 8) {
			if (state[tempx][tempy].getpiece() == null) {
				possiblemoves.add(state[tempx][tempy]);
			} else if (state[tempx][tempy].getpiece().getcolor() == this.getcolor()) {
				break;
			} else {
				possiblemoves.add(state[tempx][tempy]);
				break;
			}
			tempx++;
			tempy++;
		}
	}
}
