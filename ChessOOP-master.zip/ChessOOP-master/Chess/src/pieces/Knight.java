/**
 * Clase que representa a un caballo en el juego de ajedrez.
 * @author Erik Egido Blanes
 * @version 1.2
 * @since 2023-05-05
 */

package pieces;

import java.util.ArrayList;
import ajedrez.Celda;

public class Caballo extends Pieza {
	/**
	 * Constructor de la clase Caballo.
	 * 
	 * @param i Identificador de la pieza.
	 * @param p Ruta de la imagen de la pieza.
	 * @param c Color de la pieza (BLANCO o NEGRO).
	 */
	public Caballo(String i, String p, int c) {
		setId(i);
		setPath(p);
		setColor(c);
	}

	/**
	 * Función que devuelve una lista con las celdas a las que el caballo puede
	 * moverse.
	 * 
	 * @param state Estado actual del tablero.
	 * @param x     Fila de la celda actual de la pieza.
	 * @param y     Columna de la celda actual de la pieza.
	 * @return Lista con las celdas a las que el caballo puede moverse.
	 */
	@Override
	public ArrayList<Celda> mover(Celda state[][], int x, int y) {
		possiblemoves.clear();
		int posx[] = { x + 1, x + 1, x + 2, x + 2, x - 1, x - 1, x - 2, x - 2 };
		int posy[] = { y - 2, y + 2, y - 1, y + 1, y - 2, y + 2, y - 1, y + 1 };

		for (int i = 0; i < 8; i++) {
			if ((posx[i] >= 0 && posx[i] < 8 && posy[i] >= 0 && posy[i] < 8)) {
				if ((state[posx[i]][posy[i]].getPieza() == null
						|| state[posx[i]][posy[i]].getPieza().getColor() != this.getColor())) {
					possiblemoves.add(state[posx[i]][posy[i]]);
				}
			}
		}

		return possiblemoves;
	}
}