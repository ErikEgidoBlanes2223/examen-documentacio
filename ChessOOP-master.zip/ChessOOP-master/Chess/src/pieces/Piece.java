/**
 * Clase que representa a una pieza general en el juego de ajedrez, esta es una classe abstracta porque
 * es la madre de todas las piezas.
 * @author Erik Egido Blanes
 * @version 1.2
 * @since 2023-05-05
 */


package pieces;

import java.util.ArrayList;

import chess.Cell;


public abstract class Pieza implements Cloneable{

	/**
	
	Color de la pieza.
	*/
	private int color;
	/**
	
	Identificador de la pieza.
	*/
	private String id = null;
	/**
	
	Ruta de la imagen de la pieza.
	*/
	private String path;
	/**
	
	Lista de posibles movimientos de la pieza.
	*/
	protected ArrayList<Cell> possiblemoves = new ArrayList<Cell>();
	/**
	
	Función abstracta que debe ser implementada en las subclases para definir los movimientos de la pieza.
	
	@param pos Tablero de juego.
	
	@param x Coordenada x de la posición actual de la pieza.
	
	@param y Coordenada y de la posición actual de la pieza.
	
	@return Lista de celdas a las que puede moverse la pieza.
	*/
	public abstract ArrayList<Cell> move(Cell pos[][],int x,int y);
	
	/**
	
	Establece el identificador de la pieza.
	
	@param id Identificador de la pieza.
	*/
	public void setId(String id){
	this.id = id;
	}
	
	/**
	
	Establece la ruta de la imagen de la pieza.
	@param path Ruta de la imagen de la pieza.
	*/
	public void setPath(String path){
	this.path = path;
	}
	/**
	
	Establece el color de la pieza.
	@param c Color de la pieza.
	*/
	public void setColor(int c){
	this.color = c;
	}
	/**
	
	Obtiene la ruta de la imagen de la pieza.
	@return Ruta de la imagen de la pieza.
	*/
	public String getPath(){
	return path;
	}
	/**
	
	Obtiene el identificador de la pieza.
	@return Identificador de la pieza.
	*/
	public String getId(){
	return id;
	}
	/**
	
	Obtiene el color de la pieza.
	@return Color de la pieza.
	*/
	public int getColor(){
	return this.color;
	}
	/**
	
	Obtiene una copia de la pieza.
	@return Copia de la pieza.
	@throws CloneNotSupportedException Si la clonación no es soportada por la clase.
	*/
	public Pieza getCopia() throws CloneNotSupportedException{
	return (Pieza) this.clone();
	}
	}